package com.serakont.appbuilder2.app_types;
import com.serakont.appbuilder2.easyapp.AField;
import com.serakont.appbuilder2.easyapp.AClass;
public class ShowToast extends Action {
	@AField (init="true", types="boolean")
	private BooleanValue displayLonger;

	@AField (init="", mustHave=true, rt=true, types="string")
	private StringValue message;

}
