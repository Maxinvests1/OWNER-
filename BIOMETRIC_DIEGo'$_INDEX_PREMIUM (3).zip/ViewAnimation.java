package com.serakont.appbuilder2.app_types;
import com.serakont.appbuilder2.easyapp.AField;
import com.serakont.appbuilder2.easyapp.AClass;
public class ViewAnimation extends AppObject {
	@AField (mustHave=true, types="LayerListDrawableItemList")
	private LayerListDrawableItemList items;

}
