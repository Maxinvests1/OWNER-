package com.serakont.appbuilder2.app_types.view;
import com.serakont.appbuilder2.easyapp.AField;
import com.serakont.appbuilder2.easyapp.AClass;
public class SetBackgroundColor extends Action {
	@AField (initClass="Color", mustHave=true, rt=true, types="Color,ColorReference")
	private Color color;

}
