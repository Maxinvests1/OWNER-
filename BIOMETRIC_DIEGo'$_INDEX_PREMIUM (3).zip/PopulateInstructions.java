package com.serakont.appbuilder2.app_types.view;
import com.serakont.appbuilder2.easyapp.AField;
import com.serakont.appbuilder2.easyapp.AClass;
import com.serakont.appbuilder2.app_types.List;

public class PopulateInstructions extends List {
}
