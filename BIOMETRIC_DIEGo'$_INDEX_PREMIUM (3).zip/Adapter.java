package com.serakont.appbuilder2.app_types.view_pager;
import com.serakont.appbuilder2.easyapp.AField;
import com.serakont.appbuilder2.easyapp.AClass;
import com.serakont.appbuilder2.app_types.AppObject;

public class Adapter extends AppObject {
	@AField (initClass="Expression", mustHave=true, types="Action")
	private Action data;

	@AField (doNotDisplay=true)
	private CommonNode genLayoutId;

	@AField (types="View,LayoutReference")
	private View layout;

	@AField (types="Action")
	private Action populate;

	@AField (types="Action")
	private Action tabTitle;

}
