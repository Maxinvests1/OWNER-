package com.serakont.appbuilder2.app_types;
import com.serakont.appbuilder2.easyapp.AField;
import com.serakont.appbuilder2.easyapp.AClass;
@AClass (detail="Layout manager that allows the user to flip left and right through pages of data.")
public class ViewPager extends ViewGroup {
	@AField (initClass="ViewPager.Adapter", mustHave=true, notAttr="true", types="ViewPager.Adapter")
	private Adapter adapter;

	@AField (init="2", max=100, min=1, notAttr="true", numberType="int", types="number")
	private DoubleValue offScreenLimit;

	@AField (notAttr="true", types="TabLayout")
	private TabLayout tabs;

}
